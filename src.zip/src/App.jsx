import React from 'react'
import './App.css'
import LeftColumn from './components/LeftColumn'
import RightColumn from './components/RightColumn'
import ProductColumn from './components/Product'
import VisitorCounter from './components/VisitorCounter'
import users from './components/users'


const App = () => {
  return (
    <div className='page'>
     <LeftColumn/>
     <ProductColumn/>
     <RightColumn/>
    </div>
  )
}

export default App
