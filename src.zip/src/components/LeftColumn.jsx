import React from 'react'
import VisitorCounter from './VisitorCounter'
import Users from './Users'

const LeftColumn = () => {
  return (
    <div className='left-column'>
      <Users/>
      <VisitorCounter/>
      
    </div>
  )
}

export default LeftColumn
