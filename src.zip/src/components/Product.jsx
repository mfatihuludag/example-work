import React, { useState } from 'react'
import ProductCard from './ProductCard'

const ProductColumn = () => {
  const [products, setProducts] = useState([
    { id: 1, name: "Kulaklık", price: 450, icon: "🎧" },
    { id: 2, name: "Klavye", price: 890, icon: "⌨️" },
    { id: 3, name: "Mouse", price: 320, icon: "🖱️" },
    { id: 4, name: "Monitör", price: 3200, icon: "🖥️" },
    { id: 5, name: "Webcam", price: 650, icon: "📷" },
    { id: 6, name: "Hoparlör", price: 780, icon: "🔊" },
    { id: 7, name: "USB Hub", price: 210, icon: "🔌" },
    { id: 8, name: "Mikrofon", price: 990, icon: "🎤" },
    { id: 9, name: "Mouse Pad", price: 95, icon: "🟫" },
  ])

  return (
     <div className='product1'>
      {products.map((product) => (
        <ProductCard
          key={product.id}
          isim={product.name}
          fiyat={product.price}
          icon={product.icon}
        />
      ))}
    </div>
  )
}

export default ProductColumn