import React from 'react'

const ProductCard = (props) => {
  return (
    <div className='product-card'>
     <p className="product-icon">{props.icon}</p>
      <h3>{props.isim}</h3>
      <p className="product-price">{props.fiyat} TL</p>
    </div>
  )
}

export default ProductCard
