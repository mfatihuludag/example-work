import React, { useState } from 'react'

const Rightcolumn = () => {
 const [newComment, setnewComment] = useState("")
 const [comments, setComments] = useState([])
function yorumEkle() {
   setComments([ newComment, ...comments])
   setnewComment("")
 }
 
    return (
    <div className='right-column'>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Impedit voluptates quae eligendi!</p>
        <p>Lorem, ipsum dolor.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
        {comments.map((eleman, index) =>(<p key={index}>{eleman}</p>) )}
      <input value={newComment} onChange={(e) => setnewComment(e.target.value)}/>
<button onClick={yorumEkle}>Yorum Ekle</button>

    </div>
  )
}

export default Rightcolumn
