import React, { useState } from 'react'

const Users = () => {
  const [create, setCreate] = useState({name:"",mail:"",year:""})
  const [users, setUsers] = useState([])

 function register() {
  setUsers([...users, create])
  setCreate({name: "", mail: "", year: ""})
}
  return (
    <div className='userinfo'>
      <input
  placeholder="İsim"
  value={create.name}
  onChange={(e) => setCreate({...create, name: e.target.value})}
/>
<input placeholder='E-mail'
value={create.mail}
onChange={(e) => setCreate({...create, mail: e.target.value})} />
<input placeholder='Yaş'
value={create.year}
onChange={(e) => setCreate({...create, year: e.target.value})} />
<button onClick={register}>Kayıt Ol</button>
    </div>
  )

}

export default Users
