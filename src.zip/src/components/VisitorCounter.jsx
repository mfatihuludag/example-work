import React, { useState } from 'react'

const VisitorCounter  = () => {
    const [count, setCount] = useState (551)
  return (
    <div className='visiter'>
        <p>Ziyaretçi Sayacı</p>
        <p>{count}</p>
     <button onClick={()=> setCount(count+1)
     } >Plus</button> 
    </div>
  )
}

export default VisitorCounter
